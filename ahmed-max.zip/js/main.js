const arabicMovies = [
  {
    title: "الفيل الأزرق 2",
    image: "https://via.placeholder.com/200x300?text=الفيل+الأزرق+2",
    link: "https://vidsrc.xyz/embed/movie/tt10731256"
  },
  {
    title: "ولاد رزق",
    image: "https://via.placeholder.com/200x300?text=ولاد+رزق",
    link: "https://vidsrc.xyz/embed/movie/tt12345678"
  }
];

const foreignMovies = [
  {
    title: "Interstellar",
    image: "https://via.placeholder.com/200x300?text=Interstellar",
    link: "https://vidsrc.to/embed/movie/tt0816692"
  },
  {
    title: "Inception",
    image: "https://via.placeholder.com/200x300?text=Inception",
    link: "https://vidsrc.to/embed/movie/tt1375666"
  }
];

function renderMovies(movies, containerId) {
  const container = document.getElementById(containerId);
  movies.forEach(movie => {
    container.innerHTML += `
      <div class="movie-card">
        <img src="${movie.image}" alt="${movie.title}">
        <a href="${movie.link}" target="_blank">🎬 شاهد الآن</a>
      </div>
    `;
  });
}

renderMovies(foreignMovies, "foreign-movies");
renderMovies(arabicMovies, "arabic-movies");
